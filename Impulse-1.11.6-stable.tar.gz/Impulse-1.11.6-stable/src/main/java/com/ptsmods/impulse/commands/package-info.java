/**
 * In this package are all the commands stored.<br>
 * You should NEVER make new instances of these commands as they're registered on startup using Reflections.
 */
package com.ptsmods.impulse.commands;