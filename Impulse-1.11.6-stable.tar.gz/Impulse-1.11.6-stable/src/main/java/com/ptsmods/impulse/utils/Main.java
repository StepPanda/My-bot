package com.ptsmods.impulse.utils;

public class Main extends com.ptsmods.impulse.Main {}
