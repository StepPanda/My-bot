/**
 * @author <a href=
 *         "http://javapracs.blogspot.com/2011/06/dynamic-in-memory-compilation-using.html">javapracs</a>
 */
package com.ptsmods.impulse.utils.compiler;