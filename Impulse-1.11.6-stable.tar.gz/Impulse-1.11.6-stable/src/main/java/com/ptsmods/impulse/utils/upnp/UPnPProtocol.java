package com.ptsmods.impulse.utils.upnp;

public enum UPnPProtocol {
	TCP,
	UDP,
	BOTH;
}