# Impulse
Source code of the Impulse Discord bot.

## Dependencies
### Windows/Mac
Install the latest version of Java 8 which can be found [here](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html).
### Linux
On Linux you gotta open a terminal (ctrl+alt+t) and type the following command: `sudo apt-get install openjdk-8-jdk`, once you've installed that make sure to also install JavaFX by running `sudo apt-get install openjfx`.
