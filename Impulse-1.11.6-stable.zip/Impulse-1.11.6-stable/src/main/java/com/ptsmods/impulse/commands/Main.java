package com.ptsmods.impulse.commands;

public class Main extends com.ptsmods.impulse.Main {}
