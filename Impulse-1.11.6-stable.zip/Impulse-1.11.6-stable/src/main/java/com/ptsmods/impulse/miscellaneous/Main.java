package com.ptsmods.impulse.miscellaneous;

public class Main extends com.ptsmods.impulse.Main {}
